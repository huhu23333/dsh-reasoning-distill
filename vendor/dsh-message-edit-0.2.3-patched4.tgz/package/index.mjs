//#region src/shared.ts
/** Same-origin endpoint owned by the Message Edit host plugin. */
const MESSAGE_EDIT_PATH = "/message-edit";
/** Timeline sits between Trajectory (10) and Prompt Studio (20). */
const MESSAGE_EDIT_VIEW_ORDER = 15;
/** Current durable event schema for structurally paired version effects. */
const MESSAGE_EDIT_VERSION_SCHEMA = 2;
//#endregion
//#region src/index.ts
/** Stable Cordis plugin name. */
const name = "message-edit";
/** Public services used by the branch transaction and timeline projection. */
const inject = [
	"sessions",
	"agents",
	"sessionPersistence",
	"sessionQuery",
	"workspaceRegistry",
	"webServer"
];
function pairVersionEffect(sourceSessionId, effect) {
	return {
		schemaVersion: 2,
		effect: {
			...effect,
			id: crypto.randomUUID()
		},
		inverse: {
			kind: "restore-version",
			sessionId: sourceSessionId
		}
	};
}
function isTextualBlock(block) {
	return block?.type === "text" || block?.type === "reasoning";
}
function userText(message) {
	return message.content.filter((block) => block.type === "text").map((block) => block.text).join("\n");
}
function cloneUser(message, content = structuredClone(message.content)) {
	return Object.freeze({
		id: crypto.randomUUID(),
		role: "user",
		content: Object.freeze(content),
		source: Object.freeze({ kind: "user" })
	});
}
function replaceTextBlock(content, blockIndex, text) {
	const block = content[blockIndex];
	if (!isTextualBlock(block)) throw new Error("所选内容块不是可编辑文本。");
	return content.map((candidate, index) => index === blockIndex ? {
		...candidate,
		text
	} : structuredClone(candidate));
}
/** Fold complete turn brackets; an open tail is deliberately absent. */
function closedTurns(events) {
	const result = [];
	let current;
	for (const event of events) {
		if (event.type === "turn/start") {
			current = {
				turn: event.data.turn,
				startSeq: event.seq,
				assistants: []
			};
			continue;
		}
		if (current === void 0) continue;
		if (event.type === "user/message" && current.user === void 0 && event.data.source.kind === "user") {
			current.user = event;
			continue;
		}
		if (event.type === "assistant/message" && event.data.turn === current.turn) {
			current.assistants.push(event);
			continue;
		}
		if (event.type === "turn/end" && event.data.turn === current.turn) {
			result.push({
				...current,
				endSeq: event.seq
			});
			current = void 0;
		}
	}
	return result;
}
function editableMessages(turns) {
	const result = [];
	for (const turn of turns) {
		if (turn.user !== void 0) for (const [blockIndex, block] of turn.user.data.content.entries()) {
			if (block.type !== "text") continue;
			result.push({
				key: `${String(turn.user.seq)}:${String(blockIndex)}`,
				turn: turn.turn,
				eventSeq: turn.user.seq,
				blockIndex,
				kind: "user",
				text: block.text,
				time: turn.user.time
			});
		}
		for (const event of turn.assistants) for (const [blockIndex, block] of event.data.message.content.entries()) {
			if (!isTextualBlock(block)) continue;
			result.push({
				key: `${String(event.seq)}:${String(blockIndex)}`,
				turn: turn.turn,
				eventSeq: event.seq,
				blockIndex,
				kind: block.type === "reasoning" ? "assistant.reasoning" : "assistant.response",
				text: block.text,
				time: event.time
			});
		}
	}
	return result;
}
function retryableTurns(turns) {
	return turns.flatMap((turn) => turn.user === void 0 ? [] : [{
		turn: turn.turn,
		userEventSeq: turn.user.seq,
		preview: userText(turn.user.data),
		time: turn.user.time
	}]);
}
function downstreamUsers(turns, start) {
	return turns.slice(start).flatMap((turn) => turn.user === void 0 ? [] : [cloneUser(turn.user.data)]);
}
function assistantReplacement(event, blockIndex, text) {
	const replaced = replaceTextBlock(event.data.message.content, blockIndex, text).filter((block) => block.type === "text" || block.type === "reasoning");
	return Object.freeze({
		id: crypto.randomUUID(),
		role: "assistant",
		content: Object.freeze(replaced),
		source: Object.freeze({
			kind: "model",
			provider: event.data.message.source.provider,
			model: event.data.message.source.model
		})
	});
}
function editPlan(operation, turns) {
	const turnIndex = turns.findIndex((turn) => operation.eventSeq > turn.startSeq && operation.eventSeq < turn.endSeq);
	const turn = turns[turnIndex];
	if (turn === void 0) throw new Error("所选消息不属于已落定回合。");
	const event = turn.user?.seq === operation.eventSeq ? turn.user : turn.assistants.find((candidate) => candidate.seq === operation.eventSeq);
	if (event === void 0) throw new Error("所选消息不存在或不可编辑。");
	if (event.type === "user/message") {
		const before = event.data.content[operation.blockIndex];
		if (before?.type !== "text") throw new Error("所选用户消息块不是文本。");
		const edited = cloneUser(event.data, replaceTextBlock(event.data.content, operation.blockIndex, operation.text));
		const later = operation.cascade === "preserve" ? downstreamUsers(turns, turnIndex + 1) : [];
		return {
			boundary: turn.startSeq - 1,
			version: pairVersionEffect(operation.sessionId, {
				operation: "edit",
				cascade: operation.cascade,
				targetTurn: turn.turn,
				targetEventSeq: event.seq,
				targetBlockIndex: operation.blockIndex,
				blockKind: "user",
				before: before.text,
				after: operation.text
			}),
			queuedUsers: [edited, ...later]
		};
	}
	const before = event.data.message.content[operation.blockIndex];
	if (!isTextualBlock(before)) throw new Error("所选助手消息块不是文本或思考。");
	const blockKind = before.type === "reasoning" ? "assistant.reasoning" : "assistant.response";
	if (turn.user === void 0) throw new Error("所选助手消息没有可重建的用户输入。");
	return {
		boundary: turn.startSeq - 1,
		version: pairVersionEffect(operation.sessionId, {
			operation: "edit",
			cascade: operation.cascade,
			targetTurn: turn.turn,
			targetEventSeq: event.seq,
			targetBlockIndex: operation.blockIndex,
			blockKind,
			before: before.text,
			after: operation.text
		}),
		manualTurn: {
			turn: turn.turn,
			user: cloneUser(turn.user.data),
			assistant: assistantReplacement(event, operation.blockIndex, operation.text)
		},
		queuedUsers: operation.cascade === "preserve" ? downstreamUsers(turns, turnIndex + 1) : []
	};
}
function retryPlan(sessionId, turnNumber, cascade, turns) {
	const turnIndex = turns.findIndex((turn) => turn.turn === turnNumber);
	const turn = turns[turnIndex];
	if (turn?.user === void 0) throw new Error("所选回合没有可重放的用户输入。");
	return {
		boundary: turn.startSeq - 1,
		version: pairVersionEffect(sessionId, {
			operation: "retry",
			cascade,
			targetTurn: turn.turn,
			targetEventSeq: turn.user.seq
		}),
		queuedUsers: cascade === "preserve" ? downstreamUsers(turns, turnIndex) : [cloneUser(turn.user.data)]
	};
}
function rerollPlan(sessionId, turns) {
	for (let index = turns.length - 1; index >= 0; index -= 1) {
		const turn = turns[index];
		if (turn?.user === void 0) continue;
		const target = turn.assistants.findLast((event) => event.data.message.content.some(isTextualBlock));
		if (target === void 0) continue;
		return {
			boundary: turn.startSeq - 1,
			version: pairVersionEffect(sessionId, {
				operation: "reroll",
				cascade: "truncate",
				targetTurn: turn.turn,
				targetEventSeq: target.seq
			}),
			queuedUsers: [cloneUser(turn.user.data)]
		};
	}
	throw new Error("当前会话没有可重生成的已落定助手回复。");
}
function planOperation(operation, events) {
	const turns = closedTurns(events);
	switch (operation.action) {
		case "edit": return editPlan(operation, turns);
		case "splice": return splicePlan(operation, events);
		case "reroll": return rerollPlan(operation.sessionId, turns);
		case "retry": return retryPlan(operation.sessionId, operation.turn, operation.cascade, turns);
	}
}

/** Rewrite one assistant block in place: the branch is a copy of the whole
* conversation with that single block's text replaced. */
function splicePlan(operation, events) {
	const target = events[operation.eventSeq];
	if (target === void 0 || target.type !== "assistant/message") throw new Error("splice 目标必须是助手消息事件。");
	const before = target.data.message.content[operation.blockIndex];
	if (!isTextualBlock(before)) throw new Error("所选助手消息块不是文本或思考。");
	const user = turnUserInput(events, operation.eventSeq);
	return {
		boundary: events.length - 1,
		version: pairVersionEffect(operation.sessionId, {
			operation: "edit",
			cascade: "preserve",
			targetTurn: target.data.turn,
			targetEventSeq: target.seq,
			targetBlockIndex: operation.blockIndex,
			blockKind: before.type === "reasoning" ? "assistant.reasoning" : "assistant.response",
			before: before.text,
			after: operation.text
		}),
		splice: {
			seq: operation.eventSeq,
			blockIndex: operation.blockIndex,
			text: operation.text
		},
		// The turn this block belongs to continues in the branch as an empty user
		// input: it opens the branch's turn, and the LLM layer drops empty user
		// content, so the model resumes from the copied history without replaying
		// the request (and without redoing work it already did).
		queuedUsers: user === void 0 ? [] : [cloneUser(user.data, [])]
	};
}
/** The user input of the turn containing one event, or undefined outside a turn. */
function turnUserInput(events, seq) {
	let start = -1;
	for (let index = seq; index >= 0; index -= 1) {
		if (events[index]?.type === "turn/start") { start = index; break; }
	}
	if (start < 0) return void 0;
	for (let index = start; index < events.length; index += 1) {
		const event = events[index];
		if (event?.type === "turn/end") return void 0;
		if (event?.type === "user/message" && event.data?.source?.kind === "user") return event;
	}
	return void 0;
}
/** Copy one assistant message event with a single content block's text replaced.
* Tool-call blocks and the event envelope survive; the embedded provider stream no
* longer describes the edited content, so it is dropped. */
function splicedAssistantEvent(event, blockIndex, text) {
	const data = structuredClone(event.data);
	data.message.content[blockIndex] = {
		...data.message.content[blockIndex],
		text
	};
	data.stream = [];
	return {
		...event,
		data
	};
}
function agentOptions(events, fallback) {
	const config = events.findLast((event) => event.type === "request/header")?.data.header.config;
	const provider = config?.provider ?? fallback?.provider;
	const model = config?.model ?? fallback?.model;
	if (provider === void 0 || provider.length === 0 || model === void 0 || model.length === 0) throw new Error("无法从会话历史解析模型路由。");
	const maxTokens = config?.maxTokens ?? fallback?.maxTokens;
	return {
		provider,
		model,
		...maxTokens === void 0 ? {} : { maxTokens }
	};
}
async function withSourceAgent(ctx, sessionId, operation) {
	let handle;
	let agent = ctx.agents.get(sessionId);
	if (agent === void 0) {
		const snapshot = await ctx.sessionQuery.readSession(sessionId);
		handle = await ctx.agents.resume({
			resumeSessionId: sessionId,
			agentOptions: agentOptions(snapshot.events)
		});
		agent = handle.agent;
	}
	try {
		return await operation(agent);
	} finally {
		await handle?.dispose();
	}
}
function inheritedSeed(source, boundary) {
	if (boundary === -1) return [];
	const events = sessionLog(source);
	const boundaryEvent = events[boundary];
	if (boundary < 0 || boundaryEvent === void 0 || boundaryEvent.seq !== boundary) throw new Error("分支边界不是连续会话事件。");
	return events.slice(0, boundary + 1);
}
/** Build seed envelopes locally; Session construction performs canonical validation and freezing. */
function appendLogSeedEvent(events, type, data) {
	events.push({
		type,
		seq: events.length,
		time: Date.now(),
		data
	});
}
function appendSurfaceSeedEvent(events, type, data, intent) {
	events.push({
		type,
		seq: events.length,
		time: Date.now(),
		data,
		surfaceOp: intent.surfaceOp,
		...intent.sourceEventSeqs === void 0 ? {} : { sourceEventSeqs: intent.sourceEventSeqs }
	});
}
function appendManualTurn(events, manual) {
	const { turn, user, assistant } = manual;
	appendLogSeedEvent(events, "turn/start", { turn });
	appendSurfaceSeedEvent(events, "user/message", user, { surfaceOp: "append" });
	appendLogSeedEvent(events, "step/start", {
		turn,
		step: 1
	});
	// The host validates restored assistant settlement fields without replaying the
	// embedded stream: a synthesized message carries turn/step and an empty stream,
	// and never sourceEventSeqs (an embedded stream already carries its sources).
	appendSurfaceSeedEvent(events, "assistant/message", {
		turn,
		step: 1,
		message: assistant,
		stream: []
	}, {
		surfaceOp: "append"
	});
	appendLogSeedEvent(events, "step/end", {
		turn,
		step: 1
	});
	appendLogSeedEvent(events, "turn/end", {
		turn,
		reason: { kind: "completed" }
	});
}
function versionSeed(source, plan) {
	const events = inheritedSeed(source, plan.boundary);
	const inheritedLength = events.length;
	events.push({ type: "session/end-seed", seq: events.length, time: events.at(-1)?.time ?? Date.now(), data: { inherited: true } });
	if (plan.splice !== void 0) events[plan.splice.seq] = splicedAssistantEvent(events[plan.splice.seq], plan.splice.blockIndex, plan.splice.text);
	appendLogSeedEvent(events, "message-edit/version", plan.version);
	if (plan.manualTurn !== void 0) appendManualTurn(events, plan.manualTurn);
	return {
		events,
		inheritedLength
	};
}
function sessionPreset(session) {
	const events = sessionLog(session);
	for (let index = events.length - 1; index >= 0; index -= 1) {
		const event = events[index];
		if (event?.type === "agent-preset/selected") return event.data.agentPreset;
	}
	return session.header.agentPreset;
}
async function createVersionAgent(ctx, source, childId, plan, options) {
	const seed = versionSeed(source, plan);
	const presets = ctx.get("agentPresets");
	const presetId = sessionPreset(source);
	let agentPreset;
	let setup;
	if (presets !== void 0 && presetId !== void 0) {
		const resolved = (await presets.resolve(presetId)).id;
		agentPreset = resolved;
		setup = async (agentCtx) => {
			await presets.mount(agentCtx, resolved);
		};
	}
	const child = await ctx.agents.create({
		sessionId: childId,
		seed: seed.events,
		meta: {
			...source.header.cwd === void 0 ? {} : { cwd: source.header.cwd },
			parentSession: source.id,
			isSeeded: true,
			...agentPreset === void 0 ? {} : { agentPreset }
		},
		inheritedEventCount: seed.inheritedLength,
		agentOptions: options,
		...setup === void 0 ? {} : { setup }
	});
	try {
		await ctx.sessions.flush(child.agent.session);
		return child;
	} catch (error) {
		await child.dispose();
		throw error;
	}
}
function sourceWorkspace(ctx, sessionId) {
	return ctx.workspaceRegistry.list().find((workspace) => workspace.sessionIds.includes(sessionId));
}
async function recoverOperation(inverses) {
	const failures = [];
	for (const inverse of inverses.reverse()) try {
		await inverse();
	} catch (error) {
		failures.push(error);
	}
	if (failures.length > 0) throw new AggregateError(failures, "版本操作恢复失败。");
}
async function runOperation(ctx, operation) {
	const sourceId = sessionIdOf(operation.sessionId);
	return withSourceAgent(ctx, sourceId, async (source) => {
		const childId = sessionIdOf(`session-${crypto.randomUUID()}`);
		const inverses = [];
		try {
			const events = sessionLog(source.session);
			const plan = planOperation(operation, events);
			const options = agentOptions(events, source.options);
			const child = await createVersionAgent(ctx, source.session, childId, plan, options);
			inverses.push(() => child.dispose());
			const workspace = sourceWorkspace(ctx, sourceId);
			if (workspace !== void 0) {
				await workspace.attachSession(childId);
				inverses.push(() => workspace.detachSession(childId));
			}
			for (const message of plan.queuedUsers) child.agent.followup(message);
			inverses.length = 0;
			return {
				sessionId: childId,
				queuedTurns: plan.queuedUsers.length
			};
		} catch (error) {
			try {
				await recoverOperation(inverses);
			} catch (recoveryError) {
				throw new AggregateError([error, recoveryError], "版本操作及其恢复均失败。");
			}
			throw error;
		}
	});
}
function ownVersionEvent(header, events) {
	const inherited = header.seedLength ?? 0;
	const ownEvents = events.filter((event) => event.type === "message-edit/version" && event.seq >= inherited);
	if (ownEvents.length === 0) return void 0;
	if (ownEvents.length > 1) throw new Error(`会话 ${header.id} 包含多个自身版本效果。`);
	const event = ownEvents[0];
	if (event === void 0) return void 0;
	const parent = header.parentSession;
	if ("schemaVersion" in event.data) {
		const version = event.data;
		if (version.schemaVersion !== 2) throw new Error(`会话 ${header.id} 使用不支持的版本效果结构。`);
		if (version.inverse.kind !== "restore-version" || parent === void 0 || version.inverse.sessionId !== parent) throw new Error(`会话 ${header.id} 的版本效果与逆不匹配。`);
		return {
			effect: version.effect,
			inverseSessionId: version.inverse.sessionId,
			time: event.time
		};
	}
	const legacy = event.data;
	if (parent === void 0 || legacy.sourceSessionId !== parent) throw new Error(`会话 ${header.id} 的旧版恢复目标与父版本不匹配。`);
	return {
		effect: {
			id: `legacy:${header.id}:${String(event.seq)}`,
			operation: legacy.operation,
			cascade: legacy.cascade,
			targetTurn: legacy.targetTurn,
			targetEventSeq: legacy.targetEventSeq,
			...legacy.targetBlockIndex === void 0 ? {} : { targetBlockIndex: legacy.targetBlockIndex },
			...legacy.blockKind === void 0 ? {} : { blockKind: legacy.blockKind },
			...legacy.before === void 0 ? {} : { before: legacy.before },
			...legacy.after === void 0 ? {} : { after: legacy.after }
		},
		inverseSessionId: legacy.sourceSessionId,
		time: event.time
	};
}
function boundedInteger(name, fallback, maximum) {
	const parsed = Number.parseInt(process.env[name] ?? "", 10);
	return Number.isSafeInteger(parsed) && parsed > 0 ? Math.min(parsed, maximum) : fallback;
}
// Hard ceilings are deliberately small: this route shares the host process heap.
// The window is a suffix of the live log: wide enough to contain whole closed
// turns (a 1 MB window starved a 2.5 MB session down to its open turn alone),
// yet small enough that one request never materializes a huge projection.
const TIMELINE_EVENT_LIMIT = boundedInteger("DSH_MESSAGE_EDIT_EVENT_LIMIT", 2e3, 4e3);
const TIMELINE_INPUT_BYTE_LIMIT = boundedInteger("DSH_MESSAGE_EDIT_INPUT_BYTE_LIMIT", 4 * 1024 * 1024, 8 * 1024 * 1024);
const TIMELINE_MESSAGE_LIMIT = boundedInteger("DSH_MESSAGE_EDIT_MESSAGE_LIMIT", 200, 500);
const TIMELINE_JSON_LIMIT = boundedInteger("DSH_MESSAGE_EDIT_JSON_LIMIT", 128 * 1024, 512 * 1024);
const TIMELINE_CACHE_LIMIT = boundedInteger("DSH_MESSAGE_EDIT_CACHE_LIMIT", 16, 64);
const timelineCache = /* @__PURE__ */ new Map();
class TimelineTooLargeError extends Error {}
function timelineRevision(events) {
	return `${String(events.length)}:${String(events.at(-1)?.seq ?? 0)}`;
}
// Conservative, early-exit byte accounting; unlike JSON.stringify it never creates
// a second giant string merely to decide that an event is too large.
function bytesWithin(value, limit) {
	let bytes = 0;
	const stack = [value];
	const seen = /* @__PURE__ */ new Set();
	while (stack.length > 0 && bytes <= limit) {
		const item = stack.pop();
		if (typeof item === "string") bytes += Buffer.byteLength(item, "utf8") + 2;
		else if (typeof item === "number" || typeof item === "boolean" || item === null || item === void 0) bytes += 16;
		else if (typeof item === "object") {
			if (seen.has(item)) continue;
			seen.add(item);
			const entries = Array.isArray(item) ? item.map((entry, index) => [String(index), entry]) : Object.entries(item);
			bytes += 2 + entries.length;
			for (const [key, entry] of entries) {
				bytes += Buffer.byteLength(key, "utf8") + 3;
				stack.push(entry);
			}
		} else bytes += 16;
	}
	return bytes;
}
/** Whole closed turns counted back from the log end, oldest first.
* A raw event suffix can end inside the open turn and fold to nothing at all;
* the editable projection only ever consumes complete turn brackets. */
function recentEventWindow(events) {
	const turns = [];
	let current;
	for (const event of events) {
		if (event.type === "turn/start") {
			current = [event];
			continue;
		}
		if (current === void 0) continue;
		current.push(event);
		if (event.type === "turn/end") {
			turns.push(current);
			current = void 0;
		}
	}
	const picked = [];
	let bytes = 0;
	for (let index = turns.length - 1; index >= 0; index -= 1) {
		const turn = turns[index];
		if (picked.reduce((total, entry) => total + entry.length, 0) + turn.length > TIMELINE_EVENT_LIMIT) break;
		const remaining = TIMELINE_INPUT_BYTE_LIMIT - bytes;
		const turnBytes = bytesWithin(turn, remaining);
		if (turnBytes > remaining) break;
		bytes += turnBytes;
		picked.unshift(turn);
	}
	return picked.flat();
}
function boundedMessages(turns) {
	const candidates = editableMessages(turns);
	const result = [];
	let bytes = 0;
	for (let index = candidates.length - 1; index >= 0 && result.length < TIMELINE_MESSAGE_LIMIT; index -= 1) {
		const remaining = TIMELINE_JSON_LIMIT - bytes;
		const itemBytes = bytesWithin(candidates[index], remaining);
		if (itemBytes > remaining) continue;
		bytes += itemBytes;
		result.push(candidates[index]);
	}
	result.reverse();
	return result;
}
function boundedRetryableTurns(turns) {
	return retryableTurns(turns).slice(-TIMELINE_MESSAGE_LIMIT).map((item) => ({ ...item, preview: item.preview.slice(0, 512) }));
}
/** Final byte bound: trim the oldest entries until the real JSON fits, so a
* large turn degrades to fewer editable messages instead of an error page. */
function boundedTimeline(value) {
	const messages = [...value.messages];
	const retryableTurns = [...value.retryableTurns];
	for (;;) {
		const candidate = { ...value, messages, retryableTurns };
		if (Buffer.byteLength(JSON.stringify(candidate), "utf8") <= TIMELINE_JSON_LIMIT) return candidate;
		if (messages.length > 0) messages.splice(0, Math.max(1, Math.ceil(messages.length / 4)));
		else if (retryableTurns.length > 0) retryableTurns.splice(0, Math.max(1, Math.ceil(retryableTurns.length / 4)));
		else throw new TimelineTooLargeError(`message-edit 响应超过 ${String(TIMELINE_JSON_LIMIT)} 字节硬上限。`);
	}
}
function cacheTimeline(sessionId, revision, value) {
	if (timelineCache.has(sessionId)) timelineCache.delete(sessionId);
	timelineCache.set(sessionId, { revision, value });
	while (timelineCache.size > TIMELINE_CACHE_LIMIT) timelineCache.delete(timelineCache.keys().next().value);
}
// The host Session no longer exposes its raw `.events`; read a bounded tail
// through the supported synchronous snapshot API (older hosts: `.events`).
function liveTail(live) {
	if (typeof live.snapshotEvents === "function") {
		const end = Number(live.seq ?? 0);
		return live.snapshotEvents(Math.max(0, end - TIMELINE_EVENT_LIMIT), end);
	}
	return live.events ?? [];
}
/** Full event log of a live Session, across host API generations. */
function sessionLog(session) {
	return typeof session?.snapshotEvents === "function" ? session.snapshotEvents() : session?.events ?? [];
}

/** One version's own effect event. Only a loaded session can be read in O(1);
* a persisted branch holds a full copy of its parent's log, which this route must
* never load merely to label a row. */
function loadedVersionEvent(ctx, record) {
	const live = ctx.sessions.get(record.header.id);
	if (live === void 0 || typeof live.snapshotEvents !== "function") return void 0;
	const inherited = Number(live.inheritedEventCount ?? 0);
	if (!Number.isSafeInteger(inherited) || inherited <= 0) return void 0;
	const event = live.snapshotEvents(inherited, inherited + 1)[0];
	return event?.type === "message-edit/version" && event.data?.effect !== void 0 ? event : void 0;
}
/** Depth-first lineage from header records only: parentSessionId is the structural
* inverse link every version child is created with. */
function flattenLineage(root, descendants) {
	const result = [{ record: root, depth: 0 }];
	const visit = (nodes, depth) => {
		const ordered = [...(nodes ?? [])].sort((left, right) => (left.session?.header?.createdAt ?? 0) - (right.session?.header?.createdAt ?? 0) || String(left.session?.header?.id ?? "").localeCompare(String(right.session?.header?.id ?? "")));
		for (const node of ordered) {
			if (node?.session?.header?.id === void 0) continue;
			result.push({ record: node.session, depth });
			visit(node.descendants, depth + 1);
		}
	};
	visit(descendants, 1);
	return result;
}
/** Bounded family projection: two header-only traces plus at most one O(1) event
* read per loaded member; an absent trace falls back to a single version. */
async function lineageVersions(ctx, sessionId) {
	try {
		const target = await ctx.sessionQuery.traceSession(sessionId);
		if (target?.target?.header?.id === void 0) return void 0;
		const rootId = target.complete === true ? target.root?.header?.id : target.ancestors?.at?.(-1)?.header?.id ?? sessionId;
		const tree = rootId !== void 0 && rootId !== sessionId ? await ctx.sessionQuery.traceSession(rootId) : target;
		const lineage = flattenLineage(tree?.target ?? target.target, tree?.descendants ?? []);
		const onPath = new Set([sessionId]);
		for (const ancestor of target.ancestors ?? []) if (ancestor?.header?.id !== void 0) onPath.add(ancestor.header.id);
		const versions = lineage.map(({ record, depth }) => {
			const id = record.header.id;
			const event = loadedVersionEvent(ctx, record);
			const effect = event?.data?.effect;
			return {
				sessionId: id,
				...record.header.parentSession === void 0 ? {} : { parentSessionId: record.header.parentSession },
				...effect?.id === void 0 ? {} : { effectId: effect.id },
				...event?.data?.inverse?.sessionId === void 0 ? {} : { inverseSessionId: event.data.inverse.sessionId },
				createdAt: event?.time ?? record.header.createdAt ?? 0,
				depth,
				current: id === sessionId,
				onCurrentEffectPath: onPath.has(id),
				...effect?.operation === void 0 ? {} : { operation: effect.operation },
				...effect?.cascade === void 0 ? {} : { cascade: effect.cascade },
				...effect?.targetTurn === void 0 ? {} : { targetTurn: effect.targetTurn },
				...effect?.blockKind === void 0 ? {} : { blockKind: effect.blockKind },
				...effect?.before === void 0 ? {} : { before: effect.before },
				...effect?.after === void 0 ? {} : { after: effect.after }
			};
		});
		const byId = new Map(versions.map((version) => [version.sessionId, version]));
		const undoStack = [];
		let cursor = byId.get(sessionId)?.inverseSessionId ?? byId.get(sessionId)?.parentSessionId;
		while (cursor !== void 0 && byId.has(cursor) && !undoStack.includes(cursor)) {
			undoStack.push(cursor);
			cursor = byId.get(cursor)?.inverseSessionId ?? byId.get(cursor)?.parentSessionId;
		}
		const redoSessionIds = versions.filter((version) => version.sessionId !== sessionId && version.parentSessionId === sessionId).map((version) => version.sessionId);
		return { versions, undoStack, redoSessionIds };
	} catch {
		return void 0;
	}
}
async function timeline(ctx, sessionId) {
	const live = ctx.sessions.get(sessionId);
	if (live === void 0) return {
		sessionId,
		messages: [],
		retryableTurns: [],
		versions: [],
		undoStack: [],
		redoSessionIds: [],
		notice: "为保护宿主内存，message-edit 仅处理当前已加载会话；请先打开会话后重试。"
	};
	const events = liveTail(live);
	// The family signature joins the cache key: a new branch changes the version
	// tree without changing this session's own log.
	const family = await lineageVersions(ctx, sessionId);
	const familyRevision = family === void 0 ? "single" : family.versions.map((version) => `${version.sessionId}:${String(version.createdAt)}`).join(",");
	const revision = `${timelineRevision(events)}|${familyRevision}`;
	const cached = timelineCache.get(sessionId);
	if (cached?.revision === revision) return cached.value;
	const turns = closedTurns(recentEventWindow(events));
	const value = boundedTimeline({
		sessionId,
		messages: boundedMessages(turns),
		retryableTurns: boundedRetryableTurns(turns),
		versions: family?.versions ?? [{ sessionId, createdAt: live.header?.createdAt ?? 0, depth: 0, current: true, onCurrentEffectPath: true }],
		undoStack: family?.undoStack ?? [],
		redoSessionIds: family?.redoSessionIds ?? []
	});
	cacheTimeline(sessionId, revision, value);
	return value;
}
function objectValue(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) throw new TypeError("请求体必须是 JSON 对象。");
	return value;
}
function sessionIdOf(value) {
	if (typeof value !== "string" || value.length === 0) throw new TypeError("sessionId 必须是非空字符串。");
	return value;
}
function integerOf(value, name) {
	if (!Number.isSafeInteger(value) || value < 0) throw new TypeError(`${name} 必须是非负安全整数。`);
	return value;
}
function cascadeOf(value) {
	if (value !== "truncate" && value !== "preserve") throw new TypeError("cascade 必须是 truncate 或 preserve。");
	return value;
}
function decodeOperation(value) {
	const record = objectValue(value);
	const sessionId = sessionIdOf(record["sessionId"]);
	switch (record["action"]) {
		case "edit":
			if (typeof record["text"] !== "string") throw new TypeError("text 必须是字符串。");
			return {
				action: "edit",
				sessionId,
				eventSeq: integerOf(record["eventSeq"], "eventSeq"),
				blockIndex: integerOf(record["blockIndex"], "blockIndex"),
				text: record["text"],
				cascade: cascadeOf(record["cascade"])
			};
		case "splice":
			if (typeof record["text"] !== "string") throw new TypeError("text 必须是字符串。");
			return {
				action: "splice",
				sessionId,
				eventSeq: integerOf(record["eventSeq"], "eventSeq"),
				blockIndex: integerOf(record["blockIndex"], "blockIndex"),
				text: record["text"]
			};
		case "reroll": return {
			action: "reroll",
			sessionId
		};
		case "retry": return {
			action: "retry",
			sessionId,
			turn: integerOf(record["turn"], "turn"),
			cascade: cascadeOf(record["cascade"])
		};
		default: throw new TypeError("action 必须是 edit、splice、reroll 或 retry。");
	}
}
function requestJson(request) {
	return new Promise((resolve, reject) => {
		const decoder = new TextDecoder();
		let text = "";
		request.on("data", (chunk) => {
			text += typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
		});
		request.on("end", () => {
			try {
				text += decoder.decode();
				resolve(JSON.parse(text));
			} catch (error) {
				reject(error);
			}
		});
		request.on("error", reject);
	});
}
function respondJson(response, status, value) {
	response.writeHead(status, {
		"content-type": "application/json; charset=utf-8",
		"cache-control": "no-store"
	});
	response.end(JSON.stringify(value));
}
async function handleRoute(ctx, request, response) {
	try {
		if (request.method === "GET") {
			respondJson(response, 200, await timeline(ctx, sessionIdOf(new URL(request.url ?? "/message-edit", "http://message-edit.local").searchParams.get("sessionId"))));
			return;
		}
		if (request.method === "POST") {
			respondJson(response, 200, await runOperation(ctx, decodeOperation(await requestJson(request))));
			return;
		}
		response.writeHead(405);
		response.end();
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		respondJson(response, error instanceof TypeError ? 400 : 409, { error: message });
	}
}
/** Register the reversible route contribution. */
function apply(ctx) {
	ctx.effect(() => ctx.webServer.register({
		kind: "exact",
		path: MESSAGE_EDIT_PATH,
		handler: (request, response) => handleRoute(ctx, request, response)
	}), "message-edit: HTTP route");
}
//#endregion
export { MESSAGE_EDIT_PATH, MESSAGE_EDIT_VERSION_SCHEMA, MESSAGE_EDIT_VIEW_ORDER, apply, inject, name };
